from random import randrange, getrandbits, randint
import secrets
import sys
import os

#Recursion limit had to be increased to accommodate 2048 bit integers.
sys.setrecursionlimit(2000)
# Function to return gcd of a and b 
def gcd(a, b): 
    if (a == 0): 
        return b; 
    return gcd(b % a, a); 
  
#  Generators of p given n. Compares the GCD of both. If GCD is 1 and n is a prime
# the number n is returned as generator G of Z*P. Otherwise the function will continue to randomly generate an
# integer until conditions are met.
def Generator(n):
    if (gcd(n, p) == 1):
        if is_prime(n,128) == True:
            return n
    else:
        gflag = False
        while gflag == False:
            n = randint(1, p-1)
            if (gcd(n, p) == 1):
                if is_prime(n,128) == True:
                    gflag = True
                    return n
                else:
                    gflag = False

#This function checks to see if a number is prime using a
# Using a Miller-Rabin primality test Algorithm
def is_prime(n, k=128):
    """ Test if a number is prime
        Args:
            n -- int -- the number to test
            k -- int -- the number of tests to do
        return True if n is prime
    """
    # Test if n is not even.
    if n == 2 or n == 3:
        return True
    if n <= 1 or n % 2 == 0:
        return False
    # find r and s
    s = 0
    r = n - 1
    while r & 1 == 0:
        s += 1
        r //= 2
    # do k tests
    for _ in range(k):
        a = randrange(2, n - 1)
        x = pow(a, r, n)
        if x != 1 and x != n - 1:
            j = 1
            while j < s and x != n - 1:
                x = pow(x, 2, n)
                if x == 1:
                    return False
                j += 1
            if x != n - 1:
                return False
    return True

#prime_canidate Function generates a number that may or may not be prime
def generate_prime_candidate(length):
    """ Generate an odd integer randomly
        Args:
            length -- int -- the length of the number to generate, in bits
        return a- integer
    """
    # generate random bits
    p = secrets.randbits(length)
    # apply a mask to set MSB and LSB to 1
    p |= (1 << length - 1) | 1
    return p

#generate_prime_number Function combines both the generate_prime_canidate and is_prime function
#to generate a prime by verifying it via 128 tests. Once test is passed, the prime number will be returned as p.
def generate_prime_number(length):
    """ Generate a prime
        Args:
            length -- int -- length of the prime to generate, in bits
        return a prime
    """
    p = 4
    # keep generating while the primality test fail
    while not is_prime(p, 128):
        p = generate_prime_candidate(length)
    return p
################################################
############## Main body of program ############
#User enters a number for p. P is passed to pnew to generate a prime number.
#pmin is the minimum bit length bound and p raised to bit length becmes the upper bit length bound to search for
#a appropriate prime number for p.

while True:
  try:
    p = int(input("Please enter a number greater than 1: "))
  except ValueError:
    print("Error. Not a number.")
    continue
  if p < 2:
    continue
  else:
    break
pnew = generate_prime_number(p)
pmin = 2 ** (p-1)
p = (2 ** p)-1

#if state will seek a prime number in between 2^p-1 and 2^p bits.
#If statement will continue to search until conditions are met.
if is_prime(pnew,128) == True and (pnew <= p and pnew >= pmin):
    print("Value of p selected is:" ,pnew)
else:
    Flag = False
    while Flag == False:
        pnew = randint(pmin, p)
        Flag = is_prime(pnew,128)
    print("Value of p selected is:" ,pnew)
#Generates a g by using the generator function. If a None value error is returned (which ocassionally happens due to large integer values), the process will
#be repeated until an appropriate g is found.
n = randint(1, p-1)  
g = Generator(n);
if g == None:
    while g == None:
        n = randint(1, p-1)  
        g = Generator(n);
print("The value of g selected is :", g)

#Generate a random number a that is in the list of zP.
# if gcd(a,p) ==1, that means it is in z*p
a  = randint(1, p-1)
if gcd(a,p) == 1:
    print("Value of a selected is:" ,a)
else:
    Flag = False
    while Flag == False:
        a = randint(1, p-1)
        Flag = gcd(a,p) == 1
    print("Value of a selected is:" ,a)

#Generate a random number b that is in the list of zP.
# if gcd(b,p) == 1, that means it is in z*p
b  = randint(1, p-1)
if gcd(b,p) == 1:
    print("Value of b selected is:" ,b)
else:
    Flag = False
    while Flag == False:
        a = randint(1, p-1)
        Flag = gcd(a,p) == 1
    print("Value of b selected is:" ,b)
##Below are all the equations to generate A, B, aK = Alice Key, bK = Bob Key, and sK is the shared key that they both should get.
A = pow(g, a, p)
B = pow(g, b, p)

print("The value of A sent to Bob by Alice is:", A)
print("The value of B sent to Aice by Blice is:", B)

aK = pow(A, b, p)
bK = pow(B, a, p)
sK = pow(g,(a*b),p)

print("The value of the shared key computed by Alice is:", aK)
print("The value of the shared key computed by Bob is:", bK)
print("The value of the shared key computed by both is:", sK)
#Verifies if the keys computed are the same by comparing all three.
if aK == sK and sK == bK:
    print("The keys are verified to be the same.")
else:
    print("Error! Keys do not match!")

restart = input("\nDo you want to restart the program? [y/n] > ")

if restart == "y":
    os.startfile(__file__)
else:
    print("\nThe programm will me closed...")
    sys.exit(0)
